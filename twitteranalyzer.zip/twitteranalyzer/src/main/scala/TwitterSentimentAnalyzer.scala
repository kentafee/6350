import java.util.Properties

import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.streaming.twitter.TwitterUtils
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import twitter4j.FilterQuery

object TwitterSentimentAnalyzer {

  def main(args:Array[String]): Unit = {
    if (args.length < 1 ) {
      System.err.println("Usage: TwitterStream "+ "topic")
      System.exit(1)
    }
    val filter =args.take(1).map(_.toString).toArray;
    if (!Logger.getRootLogger.getAllAppenders.hasMoreElements) {
      Logger.getRootLogger.setLevel(Level.WARN)
    }
    val sparkConf = new SparkConf().setAppName("TwitterStreaming")
    if (!sparkConf.contains("spark.master")) {
      sparkConf.setMaster("local[2]")
    }
    val ssc = new StreamingContext(sparkConf, Seconds(2))
    val stream = TwitterUtils.createStream(ssc,None, filter)

    stream.foreachRDD(
      rdd=>{
              rdd.cache()
              val serializer = "org.apache.kafka.common.serialization.StringSerializer"
              val props = new Properties()
              props.put("bootstrap.servers", "localhost:9092")
              props.put("key.serializer", serializer)
              props.put("value.serializer", serializer)
              val producer = new KafkaProducer[String,String](props)
              rdd.collect().toList.foreach(tweet => {
                val context = tweet.getText()
                Utils.Sentimental(context)
                producer.send(new ProducerRecord[String,String]("test",context,Utils.Sentimental(context)))
              })
              producer.close()
      }
    )
    ssc.start()
    ssc.awaitTermination()
  }

}
