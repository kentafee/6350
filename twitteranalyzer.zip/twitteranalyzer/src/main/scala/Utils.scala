import java.util.Properties
import edu.stanford.nlp.pipeline.{Annotation, StanfordCoreNLP}
import edu.stanford.nlp.ling.CoreAnnotations
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations

import scala.collection.convert.wrapAll._


object Utils {

  val props = new Properties()
  props.setProperty("annotators", "tokenize, ssplit, parse, sentiment")
  val pipeline: StanfordCoreNLP = new StanfordCoreNLP(props)

  def Sentimental(txt:String): String = {
    val annotation: Annotation = pipeline.process(txt)
    val sentences = annotation.get(classOf[CoreAnnotations.SentencesAnnotation])
    val (_, sentiment) =sentences
      .map(sentence => (sentence, sentence.get(classOf[SentimentCoreAnnotations.SentimentAnnotatedTree])))
      .map { case (sentence, tree) => (sentence.toString, Sentimental(RNNCoreAnnotations.getPredictedClass(tree))) }
      .toList.maxBy { case (sentence, _) => sentence.length }
    sentiment
  }



  def Sentimental(sentiment: Int): String = sentiment match {
    case x if x == 0 || x == 1 => "Negative"
    case 2 => "Neutral"
    case x if x == 3 || x == 4 => "Positive"
  }



}
